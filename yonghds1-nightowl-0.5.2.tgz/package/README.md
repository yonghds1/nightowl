# @yonghds1/nightowl

[English](README.en.md) | 中文

自主调度技能：**plan** 交互式分析需求 → **run** 静默执行 → **report** 收尾汇总。把大需求拆成可执行的任务池，run 阶段无交互地跑完，收尾给你一份报告。

多 agent 宿主支持：**Claude Code / Codex / OpenCode / Antigravity CLI**（`nightowl init --<平台>`）。业务核心宿主无关，仅技能铺入路径、权限模型、子代理派发、headless 驱动按平台适配。

## 平台支持

| 平台 | init 别名 | 技能铺入 | 静默/权限 | headless（supervise） | 状态 |
|------|-----------|----------|-----------|----------------------|------|
| Claude Code | `--claude`（默认） | `.claude/skills/` | settings.json allow + PreToolUse hook | `claude -p --continue` | ✅ 已实测 (2.1.296) |
| Codex | `--codex` | `.agents/skills/` | `.codex/config.toml`（never+workspace-write+网络）+ hooks.json | `codex exec resume --last` | ✅ 已实测 (0.162.1) |
| OpenCode | `--opencode` | `.agents/skills/` | `opencode.json` permission 规则 | `opencode run --auto --continue` | ✅ 已实测 (1.18.35) |
| Antigravity CLI | `--antigravity` | `.agents/skills/` + `.agents/agents/` | 全局 `~/.gemini/antigravity-cli/settings.json` allow | `agy -p --dangerously-skip-permissions --continue` | ✅ 已实测 (1.3.4) |

> Codex/OpenCode/Antigravity 共享 `.agents/skills/`（跨 agent 标准目录），一次铺入三家可读。技能正文宿主无关，`init` 按平台渲染差异段（子代理派发、提问工具、启动命令）。真机实测记录详见 [`docs/platform-verification.md`](docs/platform-verification.md)，规划与机制调研见 [`docs/multi-agent-plan.md`](docs/multi-agent-plan.md)。

## 安装

```bash
npm install -g @yonghds1/nightowl
```

安装后：

- 全局 `nightowl` 命令可用
- 在每个项目里跑一次 `nightowl init`(见下),技能按项目铺入并进 git

> **技能只在项目里(按项目 `init` 铺入)**,不再维护全局拷贝。旧的全局 `~/.claude/skills/nightowl-*` 已退场,曾手动装过请删除,避免与项目技能混用漂移。包升级后跑一次 `nightowl status`,若提示"项目技能 vX < 当前包 vY",重跑 `nightowl init` 重铺即可。

## 语言

CLI 界面与命令帮助默认中文；用环境变量切英文：

```bash
NIGHTOWL_LANG=en nightowl --help
```

## 快速开始

```bash
# 1. 项目级初始化：建 .nightowl/ 任务池 + 申请权限 + 按平台铺技能
#    -u <你的名字> 写入开发者身份 (.nightowl/.developer)
#    平台别名：--claude(默认) / --codex / --opencode / --antigravity；或 --platform <id>
nightowl init -u <你的名字> --claude

# 2. 拆任务（自动生成 PRD 文档）
nightowl add --id T1 --title "实现 string_reverse" --priority P0 --est-min 15 \
  --desc "在 src/utils.ts 添加 string_reverse 函数" \
  --acceptance "空串返回空;反转正确" \
  --verify "npm test"

# 3. 查看任务池
nightowl status
```

## 分阶段工作流

将工作流 YAML 编译为现有调度器可执行的任务池，不引入新的执行引擎：

```yaml
name: feature-delivery
stages:
  - id: implement
    agent: developer
    gate_commands: ["npm run typecheck"]
    tasks:
      - id: CODE
        title: 实现功能
        priority: P1
        est_min: 30
  - id: review
    agent: reviewer
    depends_on: [implement]
    gate_commands: ["npm test"]
    tasks:
      - id: REVIEW
        title: 审查功能
        priority: P1
        est_min: 15
```

```bash
nightowl workflow generate --intent "新增登录功能" --no-apply # 从需求推导原型
nightowl workflow generate --intent "检查鉴权边界" --template audit --no-apply
nightowl workflow generate --template bugfix --no-apply     # 显式原型
nightowl workflow generate workflow.yaml            # 保存工作流，默认替换任务池
nightowl workflow generate workflow.yaml --no-apply # 仅保存、校验，不改任务池
nightowl workflow generate --apply                  # 将已保存的工作流重新应用
nightowl workflow list                             # 列出阶段、agent、任务及阶段依赖
```

`--template` 支持 `feature`、`bugfix`、`refactor`、`audit`，优先于 `--intent` 的中英文关键词推导。推导优先级为审计 → 修复 → 重构，其他需求默认 feature。file 与 `--intent` / `--template` 互斥；空意图、非法模板在落盘前报错。不传来源仍重新应用已保存工作流。

| 原型 | 阶段（agent） |
| --- | --- |
| feature | design (architect) → implement (developer) → verify (tester) → review (reviewer) |
| bugfix | diagnose (debugger) → fix (developer) → regression (tester) → review (reviewer) |
| refactor | baseline (tester) → refactor (developer) → regression (tester) → review (reviewer) |
| audit | inspect (auditor) → review (reviewer) → report (auditor) |

原型是待细化的任务骨架：用 `--no-apply` 保存后，编辑工作流中的实际任务、验收标准、估时与门禁，再 `generate --apply`。默认门禁使用 `git diff --check`、`npm run typecheck`、`npm test`，执行前须按项目适配，差异检查不等于业务验收。audit 只读分析与报告，不自动修复。生成 ID 为 `<原型>-<阶段>`，重复生成会复用 ID，开始新交付前请设置唯一任务 ID，避免旧执行状态影响调度。`init` 在四个平台铺装 `nightowl-workflows` 技能，`nightowl-plan` 按复杂度分流，简单任务仍用 `nightowl add`。

工作流保存到 `.nightowl/nightowl.workflow.yaml`，应用时替换 `.nightowl/nightowl.tasks.yaml`，**不修改独立状态文件 `nightowl.state.yaml`**（包括已完成、阻塞和进行中记录；复用任务 ID 会继续受原状态影响）。未显式配置时保留现有 `schedule` / `checkpoint` 设置；无任务池时使用初始化默认值。每个阶段至少一个任务；任务的 `status` 默认 `pending`、`depends_on` 默认空数组。

阶段 `depends_on` 引用**阶段 ID**；任务 `depends_on` 引用**任务 ID**。前置阶段的全部任务 ID 合并到当前阶段每个任务的依赖并去重，`agent` 覆盖任务的 `assignee`，`gate_commands` 合并到每个任务的 `verify` 并去重。编译会拒绝重复阶段/任务 ID、不存在的引用、阶段循环和展开后产生的任务循环；校验失败不会覆盖已有文件。门禁由原有 `nightowl verify` 执行，生成命令本身不执行门禁。

## 使用流程（三阶段）

三个阶段各有**斜杠命令**入口（Claude Code，`nightowl init` 铺入 `.claude/commands/nightowl/`）：

| 斜杠命令 | 阶段 | 说明 |
|---|---|---|
| `/nightowl:plan` | 规划 | 交互式分析需求，拆出带机器门禁的任务池 |
| `/nightowl:run` | 执行 | 静默无人值守跑完任务池 |
| `/nightowl:report` | 汇报 | 生成收尾报告并当面汇报 |

不记斜杠命令也能用：直接说"做个功能"/"开工"/"汇报"，同名技能（`nightowl-plan` / `nightowl-run` / `nightowl-report`）会按语义匹配触发，两者内容同源。

### plan —— 交互式分析需求

- `nightowl init -u <你的名字> --<平台>` 项目级初始化：建 `.nightowl/` 任务池 + 自动申请权限 + 按平台铺技能（Claude → `.claude/skills/`；Codex/OpenCode/Antigravity → `.agents/skills/`，全部进 git，clone 后即用）；`--scope local` 权限只对本机生效，`--skip-permissions` 跳过权限申请。技能版本落后当前包时 `nightowl status` 会提示，重跑 `init` 重铺
- `nightowl analyze` 分析项目上下文，生成 `.nightowl/nightowl.context.md`（技术栈/入口/测试命令/CI，run 阶段实现子代理先读它）
- `nightowl add` 加任务，字段：`--id --title --priority --est-min --assignee --desc --acceptance --depends-on --verify --slug`
- `nightowl status` 看任务池

### run —— 静默执行（无交互）

- `nightowl next` 取下一个任务：输出调度协议（`WORKTREE_ROOT` / 制表符字段 / `PRD_PATH` / `DESCRIPTION` / `ACCEPTANCE` / `VERIFY`），并带续跑检测（`# RESUME_MERGE` / `# RESUME_COMMITTED` / `# RESUME in_progress`）
- `nightowl review <id> --result PASS` 记录审查（`--level full|light`，多轮结果进 history）
- `nightowl verify <id>` 跑验收命令，通过记录 `verify_passed`
- `nightowl done <id> <actual_min>` 标记完成，**审查关口 + 测试关口 + git 核验**（校验主分支确有含 `[#<id>]` 标记的 commit；Claude 仅警告、其余平台默认阻断，`--require-commit` 可强制所有平台，`--force` 跳过全部）
- `nightowl block <id> <reason>` 阻塞（立即保存 checkpoint）
- `nightowl sweep` 清查残留 worktree（中断续跑先回收半成品）
- `nightowl push` 推送未推送的 commit（`PUSH_OK` / `PUSH_NOTHING` / `PUSH_SKIPPED_NO_REMOTE`）

**无人值守**：run 阶段可用 `nightowl supervise` 作为驱动引擎替代手动循环——按平台反复拉起宿主 headless 会话（Claude `claude -p --continue`、Codex `codex exec resume --last`、OpenCode `opencode run --auto --continue`、Antigravity `agy -p --dangerously-skip-permissions --continue`）延续主会话推进任务池，**任务池全部完成自动退出**（报告未落盘会自动拉起收尾轮兜底，退出即 run 完整结束）；中断后再启动即从断点续（续接 + resume 幂等，不重复实现已完成任务）。常用 `--interval-sec` / `--timeout-min` / `--max-idle`，调试用 `--once`。

### report —— 收尾汇总（run 后默认执行）

- `nightowl report` 生成 `.nightowl/nightowl.report.md`（任务总览 / 阻塞 / 审查过程 / git 历史），全部完成自动清理 checkpoint
- `nightowl checkpoint <save|load|clear|status>` 管理 checkpoint（双轮切换，始终留一份完整数据）

## 全部命令

| 命令 | 说明 |
|------|------|
| `init` | 项目级初始化：任务池 + 权限 + 技能（`-u <名字> --<平台>`） |
| `add` | 加任务 |
| `status` | 看状态 |
| `next` | 下一个任务 |
| `done` | 标记完成（审查 + 测试关口） |
| `block` | 阻塞 |
| `workflow generate/show/list` | 编译、应用和查看分阶段工作流 |
| `verify` | 跑验收命令 |
| `analyze` | 项目文档分析（产出项目上下文） |
| `review` | 记录审查结果 |
| `sweep` | 清查残留 worktree |
| `push` | 推送未推送 commit |
| `report` | 生成报告 |
| `resume` | 崩溃续跑 |
| `checkpoint` | checkpoint 管理 |
| `supervise` | 无人值守驱动主会话（按平台循环拉起宿主 headless 延续 run，任务池完成退出） |

## 项目级技能

`nightowl init` 会把技能按项目铺入（trellis 式，进 git，clone 后即用）：

- 技能 → Claude：`.claude/skills/nightowl-{plan,run,report}/`；Codex/OpenCode/Antigravity：`.agents/skills/nightowl-{plan,run,report}/`（跨 agent 共享目录）
- Antigravity 额外铺子代理定义 `.agents/agents/nightowl-{implementer,reviewer}.md`（供 `invoke_subagent` 调用）
- 技能正文宿主无关，`init` 按平台把 `{{PLATFORM_*}}` 占位符渲染成对应平台的子代理派发/提问/启动方式（切换平台后重跑 `init` 即重铺为当前平台的渲染产物）
- 模板 hash 记录在 `.nightowl/.template-hashes.json`：记录每个铺入文件的 hash + 技能来源版本戳。包升级后再次 `nightowl init` 自动更新未定制的文件；被本地定制过的跳过（`--force` 覆盖）。`nightowl status` 检测项目技能版本落后当前包时提示重跑 `init`
- 身份 → `.nightowl/.developer`（`-u` 写入，建议加入 .gitignore）

## 工作原理

状态全部落在项目根 `.nightowl/` 目录，不依赖对话记忆：

| 文件 | 用途 |
|------|------|
| `nightowl.tasks.yaml` | 任务池（schedule / checkpoint / pool） |
| `nightowl.state.yaml` | 运行时状态（completed / blocked / in_progress） |
| `nightowl.checkpoint.yaml`(+`.backup`) | checkpoint，双轮切换原子写 |
| `nightowl.log` | 操作日志 |
| `nightowl.supervisor.log` | 无人值守驱动日志（supervise 每轮状态与宿主输出） |
| `nightowl.context.md` | 项目上下文（`analyze` 生成，实现子代理先读它） |
| `nightowl.report.md` | 收尾报告（`report` 生成） |
| `.template-hashes.json` | 技能模板 hash + 技能来源版本戳（`init` 更新检测 / `status` 版本自检） |
| `.developer` | 开发者身份（`init -u` 写入），建议加入 .gitignore |
| `tasks/<assignee>/<MM-DD-slug>/prd.md` | 每个任务关联的 PRD 文档(按负责人分层) |

`--dir <项目根>` 全局选项可在任意目录指定项目根（默认当前目录）。

## 开发

```bash
npm run build      # tsc 编译到 dist/
npm test           # 构建 + vitest 全量测试
npm run dev        # tsx 直接跑 src/cli.ts
npm run typecheck  # 类型检查
```

## License

[ISC](LICENSE)
